#version 330
#extension GL_ARB_separate_shader_objects : require

// Opalithium: 마크 26.3 text.fsh 그대로 + 시즌 칭호 아이콘 움직임 (2026-11-27).
// text.vsh 가 글자 색 #FEFEF0 인 글자에 seasonFx = 1, 그 그림자에 2 를 줌. 그림의 알파 표시 (gen_season_title_font.py / season_title_art3.py):
//   253 = 숫자 (대각선 빛줄기가 가끔 지나감), 252 = 반짝임 가운데 (밝아졌다 어두워짐), 251 = 반짝임 팔 (반짝일 때만 보임)
//   250 / 249 = 반짝임 가운데 / 팔인데 밑에 그림이 있음 (그림 색은 밑 그림, 켜질 때만 반짝임 색으로)

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) flat in int seasonFx;
layout(location = 5) in vec2 glyphPos;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

bool alphaIs(float a, float k) {
    return abs(a * 255.0 - k) < 0.5;
}

vec4 seasonEffect(vec4 tex, bool shadow) {
    float t = GameTime * 1200.0; // 초
    if (alphaIs(tex.a, 253.0)) {
        if (shadow) return vec4(tex.rgb, 1.0); // 숫자: 4초마다 왼쪽 아래 -> 오른쪽 위 빛줄기
        float d = glyphPos.x + (1.0 - glyphPos.y);          // 0 (왼아래) .. 2 (오른위)
        float c = fract(t / 4.0) * 3.2 - 0.6;               // 줄기 자리 (대부분은 그림 밖에서 쉼)
        float k = 1.0 - smoothstep(0.0, 0.16, abs(d - c));
        return vec4(mix(tex.rgb, vec3(1.0), 0.65 * k), 1.0);
    }
    float tw = pow(0.5 + 0.5 * sin(t * 2.6), 3.0);           // 반짝임 세기 (0..1)
    // 2026-11-27 사용자: 반짝이지 않을 때는 반짝임이 아예 없고 뒤 그림 (화살표·칼) 이 보이게
    float on = tw > 0.12 ? tw : 0.0, armOn = tw > 0.45 ? tw : 0.0;
    vec3 spark = shadow ? vec3(1.0) : vec3(1.0, 1.0, 0.925), arm = shadow ? vec3(1.0) : vec3(1.0, 0.973, 0.784);
    if (alphaIs(tex.a, 252.0)) return vec4(tex.rgb, on);                         // 밑이 빈 칸: 켜질 때만 보임
    if (alphaIs(tex.a, 251.0)) return vec4(tex.rgb, armOn);
    if (alphaIs(tex.a, 250.0)) return vec4(mix(tex.rgb, spark, on), 1.0);        // 밑에 그림: 꺼지면 밑 그림 그대로
    if (alphaIs(tex.a, 249.0)) return vec4(mix(tex.rgb, arm, armOn), 1.0);
    return tex;
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    if (seasonFx != 0) texColor = seasonEffect(texColor, seasonFx == 2);

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
